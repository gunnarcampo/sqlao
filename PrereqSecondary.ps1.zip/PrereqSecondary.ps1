﻿configuration PrereqSecondary 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds        
    ) 
    
    Import-DscResource -ModuleName PSDesiredStateConfiguration ,xActiveDirectory, xComputerManagement, xStorage, xNetworking , xSQLServer

    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
   
    Node localhost
    {                
        LocalConfigurationManager            
        {            
            ActionAfterReboot = 'ContinueConfiguration'            
            ConfigurationMode = 'ApplyOnly'            
            RebootNodeIfNeeded = $true            
        }    
        
        Registry DisableUAC
        {
            Key         = "HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\policies\system"
            ValueName   = "EnableLUA"
            ValueData   = "0"
        }

        xWaitforDisk Disk2
        {
             DiskId = '2'
             RetryIntervalSec = 60
             RetryCount = 60
        }
        
        xDisk HDrive
        {
             DiskId = '2'
             DriveLetter = 'H'             
        }      

        WindowsFeature ADPowershell
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        } 

        xWaitForADDomain WaitForDomain 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $Admincreds
            RetryCount = 20
            RetryIntervalSec = 30
            DependsOn = "[WindowsFeature]ADPowershell" 
        }

        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = "[xWaitForADDomain]WaitForDomain" 
        }       
        
        WindowsFeature AddFailoverFeature
        {
            Ensure = 'Present'
            Name   = 'Failover-clustering'
        }
        
        WindowsFeature FailoverClusterTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-Clustering-Mgmt"
			DependsOn = "[WindowsFeature]AddFailoverFeature"
        } 
        
        WindowsFeature AddRemoteServerAdministrationToolsClusteringPowerShellFeature
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-PowerShell'
            DependsOn = '[WindowsFeature]AddFailoverFeature'
        }

        WindowsFeature AddRemoteServerAdministrationToolsClusteringCmdInterfaceFeature
        {
            Ensure    = 'Present'
            Name      = 'RSAT-Clustering-CmdInterface'
            DependsOn = '[WindowsFeature]AddRemoteServerAdministrationToolsClusteringPowerShellFeature'
        }          

         xFirewall DatabaseEngineFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            Group = "SQL Server"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "1433"
            Ensure = "Present"
        }

        xFirewall DatabaseMirroringFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            Group = "SQL Server"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "5022"
            Ensure = "Present"
        }

        xFirewall ListenerFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            Group = "SQL Server"
            Enabled = "True"
            Action = "Allow"
            Protocol = "TCP"
            LocalPort = "59999"
            Ensure = "Present"
        }
        
        xSQLServerLogin AddDomainAdminAccountToSysadminServerRole
        {
            SQLServer = "localhost"
            SQLInstanceName = "MSSQLSERVER"
            Name = "$($DomainName.Substring(0,$DomainName.IndexOf('.')))\$($Admincreds.UserName)" 
            LoginType = "WindowsUser"                        
            Ensure = "Present"
            PsDscRunAsCredential =  $Admincreds       
            DependsOn = "[xComputer]DomainJoin" 
        }

        xSQLServerRole AddInstallAccountTosysadmin
        {
            Ensure               = 'Present'
            ServerRoleName       = 'sysadmin'
            MembersToInclude     = "$($DomainName.Substring(0,$DomainName.IndexOf('.')))\$($Admincreds.UserName)" 
            SQLServer            = 'localhost'
            SQLInstanceName      = 'MSSQLSERVER'
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[xSQLServerLogin]AddDomainAdminAccountToSysadminServerRole" 
        }                

        # for this POC lets piggy back on this same domain account as a service account
        xSQLServerServiceAccount SetServiceAcccount_User
        {
            SQLServer = 'localhost'
            SQLInstanceName = 'MSSQLSERVER'
            ServiceType = 'DatabaseEngine'
            ServiceAccount = $DomainCreds
            RestartService = $true
            DependsOn = "[xSQLServerRole]AddInstallAccountTosysadmin" 
        }                                        
   }
} 
