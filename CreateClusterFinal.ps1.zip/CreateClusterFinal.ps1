﻿configuration CreateClusterFinal
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,        

        [Parameter(Mandatory)]
        [String]$ClusterName,
        
        [Parameter(Mandatory)]
        [String[]]$Nodes        

    )

    Import-DscResource -ModuleName  xFailOverCluster
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {                

        xCluster FailoverCluster
        {
            Name = $ClusterName
            DomainAdministratorCredential = $DomainCreds
            Nodes = $Nodes
        }     
    }
}